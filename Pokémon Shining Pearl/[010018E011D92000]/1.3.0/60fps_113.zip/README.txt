60FPS Mod made by MelonSpeedruns

1.1.3 version by Yisuno

Installation guide:
-Extract the .ZIP file
-Create a folder with any name, like (60FPS mod)
-Put the .ZIP content in that folder
-Move the folder tho your Switch/Emulator Mod folder
-Enjoy!

Original mod made by MelonSpeedruns